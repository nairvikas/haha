/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package authentication;

import global.DbConn;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONException;
import org.json.JSONObject;
import util.addQuestionList;

/**
 *
 * @author acer
 */
public class LoginAuthentication extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws org.json.JSONException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, JSONException {
        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        HttpSession session = request.getSession(false);
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String type = request.getParameter("type");
        JSONObject messageObject = new JSONObject();
        boolean validAuthentication = false;
        boolean queryExecuted = true;
        String loginUserQuery = "";

        if (username == null) {
            username = "NA";
        }

        try (PrintWriter out = response.getWriter()) {
            try (Connection con = DbConn.getDbConnection();) {
                if (con != null) {

                    switch (type) {
                        case "ADMIN":
                            loginUserQuery = "select * from admin";
                            break;
                        case "EMPLOYEE_AM":
                            loginUserQuery = "select * from admin";
                            break;
                        case "EMPLOYEE_DM":
                            loginUserQuery = "select * from admin";
                            break;
                        case "EMPLOYEE_DM1":
                            loginUserQuery = "select * from admin";
                            break;

                    }

                    try (PreparedStatement pstmt = con.prepareStatement(loginUserQuery);) {
                        pstmt.setString(1, username);
                        pstmt.setString(2, password);
                        try (ResultSet rs = pstmt.executeQuery();) {
                            while (rs.next()) {
                                validAuthentication = true;
                            }
                        }
                    }
                } else {
                    queryExecuted = false;
                }
            } catch (Exception ex) {
                System.out.println("loginAuthentication ..." + ex);
                queryExecuted = false;
            }
            if (queryExecuted) {
                if (validAuthentication) {
                    switch (type) {
                        case "ADMIN":
                            session.setAttribute("user", username);
                            session.setAttribute("type", type);
                            messageObject.put("status", "S");
                            break;
                        default:

                            String quizAtempted = addQuestionList.alreadyAttempted(username, type);
                            switch (quizAtempted) {
                                case "ERROR":
                                    messageObject.put("status", "E");
                                    messageObject.put("message", "Please Try Later");
                                    break;
                                case "YES":
                                    messageObject.put("status", "ATTEMPTED");
                                    messageObject.put("message", "Already Attempted");
                                    break;
                                case "NO":
                                    String questionList = addQuestionList.getGroupQuestionList(type);
                                    switch (questionList) {
                                        case "ERROR":
                                            messageObject.put("status", "E");
                                            messageObject.put("message", "Please Try Later");
                                            break;
                                        default:
                                            String[] groupListQuestion = questionList.split("###");
                                            String result = addQuestionList.userQuestionList(username, type, groupListQuestion);
                                            switch (result) {
                                                case "ERROR":
                                                    messageObject.put("status", "E");
                                                    messageObject.put("message", "Please Try Later");
                                                    break;
                                                case "S":
                                                    messageObject.put("status", "S");
                                                    session.setAttribute("user", username);
                                                    session.setAttribute("type", type);
                                                    session.setAttribute("firstQuestion", groupListQuestion[0]);
                                                    break;
                                                default:
                                                    messageObject.put("status", "E");
                                                    messageObject.put("message", "Please Try Later");
                                            }

                                    }

                                    break;
                                default:
                                    messageObject.put("status", "E");
                                    messageObject.put("message", "Please Try Later");
                            }
                    }

                } else {
                    messageObject.put("status", "E");
                    messageObject.put("message", "Wrong Username/Password");
                }

            } else {
                messageObject.put("status", "E");
                messageObject.put("message", "Please Try Later");
            }

            out.print(messageObject);
        }
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);

        } catch (JSONException ex) {
            Logger.getLogger(LoginAuthentication.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);

        } catch (JSONException ex) {
            Logger.getLogger(LoginAuthentication.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
