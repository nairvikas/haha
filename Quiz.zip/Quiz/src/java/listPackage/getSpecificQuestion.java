/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listPackage;

import global.DbConn;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author acer
 */
public class getSpecificQuestion extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws org.json.JSONException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, JSONException {
        response.setCharacterEncoding("utf-8");
        response.setContentType("application/json");
        HttpSession session = request.getSession(false);
        boolean loggedIn = true;
        String loginId = "";
        String type = "";
        JSONObject mainObject = new JSONObject();
        JSONArray optionList = new JSONArray();

        try (PrintWriter out = response.getWriter()) {
            try {
                loginId = (String) session.getAttribute("user");
            } catch (Exception ex) {
                loggedIn = false;
            }

            if (loggedIn) {
                try (Connection con = DbConn.getDbConnection();) {
                    if (con != null) {
                        try (PreparedStatement pstmt = con.prepareStatement("");) {
                            pstmt.setString(1, loginId);
                            try (ResultSet rs = pstmt.executeQuery();) {
                                while (rs.next()) {
                                    mainObject.put("QUESTION", rs.getString(""));
                                    mainObject.put("QUESTION_ID", rs.getString(""));
                                }
                            }
                        }
                        try (PreparedStatement pstmt = con.prepareStatement("");) {
                            pstmt.setString(1, loginId);
                            try (ResultSet rs = pstmt.executeQuery();) {
                                while (rs.next()) {
                                    optionList.put(rs.getString(""));
                                }
                            }
                        }
                        mainObject.put("RESULT", "S");
                        mainObject.put("OPTIONLIST", optionList);

                    } else {
                        mainObject.put("RESULT", "E");
                    }
                } catch (Exception ex) {
                    System.out.println("getSpecificQuestion ..." + ex);
                    mainObject.put("RESULT", "E");
                }

            } else {
                mainObject.put("RESULT", "E");
            }
            out.print(mainObject);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (JSONException ex) {
            Logger.getLogger(getSpecificQuestion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (JSONException ex) {
            Logger.getLogger(getSpecificQuestion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
