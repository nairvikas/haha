/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import global.DbConn;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author acer
 */
public class addQuestionList {

    public static String userQuestionList(String userName, String type, String[] groupListQuestion) {
        String result;
        result = "ERROR";
        String userQuestionQuery = "";
0
        switch (type) {
            case "EMPLOYEE_AM":
                userQuestionQuery = "Insert into mst_am_answer(login_id, question_id, answer_id) values (?,?,?)";
                break;
            case "EMPLOYEE_DM":
                userQuestionQuery = "Insert into mst_dm_answer(login_id, question_id, answer_id) values (?,?,?)";
                break;
            case "EMPLOYEE_DM1":
                userQuestionQuery = "Insert into mst_dm1_answer(login_id, question_id, answer_id) values (?,?,?)";
                break;

        }

        try (Connection con = DbConn.getDbConnection();) {
            if (con != null) {
                try (PreparedStatement pstmt = con.prepareStatement(userQuestionQuery);) {
                    for (int i = 0; i < groupListQuestion.length; i++) {
                        pstmt.setString(1, userName);
                        pstmt.setString(2, Integer.toString(i));
                        pstmt.setString(3, "NA");
                        pstmt.addBatch();
                    }
                    int[] results = pstmt.executeBatch();
                    result = "S";

                }
            } else {
                result = "ERROR";
            }
        } catch (Exception ex) {
            System.out.println("userQuestionList..." + ex);
            result = "ERROR";

        }

        return result;
    }

    public static String alreadyAttempted(String userName, String type) {
        String quizAtempted = "NO";
        try (Connection con = DbConn.getDbConnection();) {
            if (con != null) {
                try (PreparedStatement pstmt = con.prepareStatement("");) {
                    pstmt.setString(1, userName);
                    try (ResultSet rs = pstmt.executeQuery();) {
                        while (rs.next()) {
                            quizAtempted = "YES";
                        }
                    }
                }
            } else {
                quizAtempted = "ERROR";
            }
        } catch (Exception ex) {
            System.out.println("alreadyAttempted ..." + ex);
            quizAtempted = "ERROR";
        }
        return quizAtempted;
    }

    public static String getGroupQuestionList(String type) {
        String groupQuestionListQuery = "";
        String questionList = "ERROR";
        switch (type) {
            case "EMPLOYEE_AM":
                groupQuestionListQuery = "select QUESTION_LIST from MST_EMPLOYEE_AM_QUESTION_LIST where QUESTION_ID=? ";
                break;
            case "EMPLOYEE_DM":
                groupQuestionListQuery = "select QUESTION_LIST from MST_EMPLOYEE_DM_QUESTION_LIST where QUESTION_ID=? ";
                break;
            case "EMPLOYEE_DM1":
                groupQuestionListQuery = "select QUESTION_LIST from MST_EMPLOYEE_DM1_QUESTION_LIST where QUESTION_ID=? ";
                break;

        }

        try (Connection con = DbConn.getDbConnection();) {
            if (con != null) {
                try (PreparedStatement pstmt = con.prepareStatement(groupQuestionListQuery);) {
                    pstmt.setString(1, "1");
                    try (ResultSet rs = pstmt.executeQuery();) {
                        while (rs.next()) {
                            questionList = rs.getString("QUESTION_LIST");
                        }
                    }
                }
            } else {
                questionList = "ERROR";
            }
        } catch (Exception ex) {
            System.out.println("getGroupQuestionList ..." + ex);
            questionList = "ERROR";
        }

        return questionList;

    }

}
